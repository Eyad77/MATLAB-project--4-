clear all

obj = VideoReader('highway.avi');
a= read(obj);

frames=get(obj,'NumberOfFrames');

%extracting Frames

for i=1:frames
     I(i).cdata=a(:,:,:,i);
end   

s=size(I(1).cdata);
mov(1:frames) =struct('cdata', zeros(s(1),s(2), 3, 'uint8'),'colormap', []);
 
for Frame=1:frames
    
%Red Components of the Frame
R=I(Frame).cdata(:,:,1);

%Green Components of the Frame
G=I(Frame).cdata(:,:,2); 

%Blue Components of the Frame
B=I(Frame).cdata(:,:,3);

trellis = poly2trellis(7,[171 133]);


Rtable = Packets(R);
Gtable = Packets(G);
Btable = Packets(B);

p=0.001 ; 

%encoding here
 
%%encode and send on bsc with p(e)= p

puncat1 = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

[Renc,Rrec] = Encode(Rtable,trellis,2048,puncat1,p,1);
[Genc,Grec] = Encode(Gtable,trellis,2048,puncat1,p,1);
[Benc,Brec] = Encode(Btable,trellis,2048,puncat1,p,1);



 %decoding here
 
  Rdecode = Decode(Rrec,trellis,1024,puncat1);
   Gdecode = Decode(Grec,trellis,1024,puncat1);
   Bdecode = Decode(Brec,trellis,1024,puncat1);
 
%    [CheckedR,Through]  = IncRed(  Rtable,trellis,Rdecode,p) ;
%    [CheckedG,Through]  = IncRed(  Gtable,trellis,Gdecode,p) ; 
%    [CheckedB,Through]  = IncRed(  Btable,trellis,Bdecode,p) ; 
%  
%Converting rback to Video

Rback = Reversing(Rdecode); 
Gback = Reversing( Gdecode );
Bback = Reversing( Bdecode );

Rback = uint8(Rback);
Gback = uint8(Gback);
Bback = uint8(Bback);



%constracting frame back
 mov(1,Frame).cdata(:,:,1) = Rback; 
 mov(1,Frame).cdata(:,:,2) = Gback;
 mov(1,Frame).cdata(:,:,3) = Bback;


end

 

%saving the new Movie
Obj_new = VideoWriter('newfile.avi','Motion JPEG AVI');
open(Obj_new);
writeVideo(Obj_new,mov);
close(Obj_new);



