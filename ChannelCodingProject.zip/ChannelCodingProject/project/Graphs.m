clear all

obj = VideoReader('highway.avi');
a= read(obj);

frames=get(obj,'NumberOfFrames');

%extracting Frames

for i=1:frames
     I(i).cdata=a(:,:,:,i);
end   

s=size(I(1).cdata);
mov(1:frames) =struct('cdata', zeros(s(1),s(2), 3, 'uint8'),'colormap', []);
 

j=1;
for p=0.001 :0.0199: 0.2
    
%Red Components of the Frame
R=I(1).cdata(:,:,1);

%Green Components of the Frame
G=I(1).cdata(:,:,2); 

%Blue Components of the Frame
B=I(1).cdata(:,:,3);

trellis = poly2trellis(7,[171 133]);


Rtable = Packets(R);
Gtable = Packets(G);
Btable = Packets(B);



%encoding here
 
%%encode and send on bsc with p(e)= p

puncat1 = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

[Renc,Rrec] = Encode(Rtable,trellis,2048,puncat1,p,1);
[Genc,Grec] = Encode(Gtable,trellis,2048,puncat1,p,1);
[Benc,Brec] = Encode(Btable,trellis,2048,puncat1,p,1);



 %decoding here
 
   Rdecode = Decode(Rrec,trellis,1024,puncat1);
   Gdecode = Decode(Grec,trellis,1024,puncat1);
   Bdecode = Decode(Brec,trellis,1024,puncat1);
 
   [CheckedR,Ry]  = IncRed(  Rtable,trellis,Rdecode,p) ;
   [CheckedG,Gy]  = IncRed(  Gtable,trellis,Gdecode,p) ; 
   [CheckedB,By]  = IncRed(  Btable,trellis,Bdecode,p) ; 


%Converting rback to Video

Rback = Reversing(Rdecode); 
Gback = Reversing( Gdecode );
Bback = Reversing( Bdecode );

Rback = uint8(Rback);
Gback = uint8(Gback);
Bback = uint8(Bback);



%constracting frame back
 mov(1,1).cdata(:,:,1) = Rback; 
 mov(1,1).cdata(:,:,2) = Gback;
 mov(1,1).cdata(:,:,3) = Bback;

 %Bit error Rate
%   [Rx,Ry]=biterr( I(1).cdata(:,:,1) , mov(1).cdata(:,:,1));
%   [Gx,Gy]=biterr( I(1).cdata(:,:,2) , mov(1).cdata(:,:,2));
%   [Bx,By]=biterr( I(1).cdata(:,:,3) , mov(1).cdata(:,:,3));


  v1(1,j)=Ry;
  v2(1,j)=Gy;
  v3(1,j)=By;

  j=j+1;
end

prop = 0.001:0.0199:0.2 ; 

plot (prop,v1);
hold on 
plot (prop,v2);
hold on 
plot (prop,v3);

hold off

