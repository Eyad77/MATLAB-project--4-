function [ back ] = Reversing( Rtable )

back = zeros(128,198);

for i=1:198
    
   
    t= Rtable(:,i);
    t=reshape(t,8,128);
    for j=1:128
       x = t(:,j);
       x=transpose(x);
       x=fliplr(x);
       x=bi2de(x);
       
       back(j,i)=x;
        
    end
end

back=reshape(back,144,176);




end

