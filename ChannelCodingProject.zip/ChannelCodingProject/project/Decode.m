function [ decode ] = Decode( Renc , trellis ,size,puncat)

decode=zeros(size,198);

for i=1:198 
   
   decode(:,i) = vitdec(Renc(:,i),trellis,35,'trunc','hard',puncat); 
   
end


end

