function [ encode,Rec ] = Encode( Rtable,trellis,size,puncat,p,x)


encode=zeros(size,198);
Rec = encode ; 



for i=1:198

    if (x==1)
    encode(:,i)=convenc( Rtable(:,i) ,trellis,puncat); 
    Rec(:,i) = bsc( encode(:,i), p);

    else
        
        Rec(:,i) = bsc( Rtable(:,i), p);
    end

end


end

