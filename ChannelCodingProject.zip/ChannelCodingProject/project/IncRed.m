function [ Checked,Through ] = IncRed(  Rtable,trellis,Rdecode,P)

Checked =zeros(1024,198);
 Through = 0;

for i=1:198
   check = Rdecode(:,i) == Rtable(:,i) ;
   temp = find(check==0) ; 
   
   if( length(temp)~=0 ) 
     
     %% Rate 4/5
    Enc =convenc( Rtable(:,i) ,trellis,[1 1 1 0 1 0 1 0 1 1 1 0 1 0 1 0]);   
    Rec = bsc( Enc , P);
    
    Dec =  vitdec( Rec ,trellis,35,'trunc','hard',[1 1 1 0 1 0 1 0 1 1 1 0 1 0 1 0]); 
       
    check = Dec == Rtable(:,i) ;
    temp = find(check==0) ; 
       
        if( length(temp)~=0 ) 
       
          %% Rate 2/3
          
          Enc =convenc( Rtable(:,i) ,trellis,[1 1 1 0 1 1 1 0 1 1 1 0 1 1 1 0]);   
          Rec = bsc( Enc , P);
          
          Dec =  vitdec( Rec ,trellis,35,'trunc','hard',[1 1 1 0 1 1 1 0 1 1 1 0 1 1 1 0]);
          
          check = Dec == Rtable(:,i) ;
          temp = find(check==0) ;
          
           if( length(temp)~=0 ) 
              
              %%Rate 4/7
               
              Enc =convenc( Rtable(:,i) ,trellis,[1 1 1 1 1 1 1 0 1 1 1 1 1 1 1 0]);   
          Rec = bsc( Enc , P);
          
          Dec =  vitdec( Rec ,trellis,35,'trunc','hard',[1 1 1 1 1 1 1 0 1 1 1 1 1 1 1 0]);
          
          check = Dec == Rtable(:,i) ;
          temp = find(check==0) ;  
               
             if( length(temp)~=0 )   
             
               %%Rate 1/2  
                 
             EncHalf =convenc( Rtable(:,i) ,trellis);   
          RecHalf = bsc( EncHalf , P);
          
          DecHalf =  vitdec( RecHalf ,trellis,35,'trunc','hard');
              
              Checked(:,i) = DecHalf ;   
               
              Through = Through+ (1024* 2);
                 
                 
                 
                 
             else
              Checked(:,i) = Dec ; 
               Through = Through+ (1024* 7/4);
               
           end
               
               
           else
              Checked(:,i) = Dec ; 
               Through = Through+ (1024* 3/2);
               
           end
          
            
        else
            Checked(:,i) = Dec ; 
             Through = Through+ (1024* 5/4);
        end
    
   else
        Checked(:,i) = Rdecode(:,i) ;
         Through = Through+ (1024* 9/8);
       
   end
   
   
   
       
end
 




end

