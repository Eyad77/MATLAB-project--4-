function [ Rtable ] = Packets( R )

R = double(R);

R = reshape(R,128,198);

Rtable = zeros(1024,198);

 for i = 1:198
     temp =R(:,i) ; 
     temp=dec2bin(temp);
     temp=transpose(temp);
     temp=reshape(temp,1024,1);
     
         for k = 1:1024
             Rtable(k,i)= str2double(temp(k));
         end
    
 end



end

